export interface MyButtonProps {
  label?: string;
  disabled?: boolean;
  backgroundColor?: string;
}
