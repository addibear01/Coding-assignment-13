export { default } from './MyHeroImage';
