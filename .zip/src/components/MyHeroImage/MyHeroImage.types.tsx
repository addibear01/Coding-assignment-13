export interface MyHeroImageProps {
    src: string;
    disabled?: boolean;
    backgroundColor?: string;
  }
  