export interface MyImageProps {
    src: string;
    disabled?: boolean;
}
