export { default } from './MyImage';
