export interface MyLabelProps {
    disabled?: boolean;
    text?: string;
    backgroundColor?: string; // Add background color prop
  }
  
  
