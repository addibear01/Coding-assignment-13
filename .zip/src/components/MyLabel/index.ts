export { default } from './myLabel';
