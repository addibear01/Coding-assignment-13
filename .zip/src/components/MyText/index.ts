export { default } from './myText';
