export interface MyTextProps {
    disabled?: boolean;
    text?: string;
    backgroundColor?: string;
  }
  